<#
    Title:   Mulesoft Logs Collector
    Language:PowerShell
    Version: 1.0
    Author:  Rogier Dijkman
    Last Modified:  03/28/2022

    DESCRIPTION
    This Function App calls an API to pull the Audit logs.
    The response from the Mulesoft API is recieved in JSON format. This function will build the signature and authorization header needed to
    post the data to the Log Analytics workspace via the HTTP Data Connector API.

    The Function App will post each log type to their individual tables in Log Analytics, for example,
    Mulesoft_CL
#>

# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

# Main
if ($env:MSI_SECRET -and (Get-Module -ListAvailable Az.Accounts)) {
    Connect-AzAccount -Identity
}

$AzureWebJobsStorage     = $env:AzureWebJobsStorage
$workspaceId             = $env:WorkspaceId
$workspaceKey            = $env:workspaceKey | ConvertTo-SecureString -AsPlainText -Force
$storageAccountContainer = "custom-logs"
$apiResponseLimit        = $env:apiResponseLimit
$AuditLogTable           = "MuleLogs"
$timeOffset              = 0

$currentStartTime = (Get-Date).toLocalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')

Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"
$rfc1123date = [DateTime]::UtcNow.ToString("r")

$storageAccountContext = New-AzStorageContext -ConnectionString $AzureWebJobsStorage

#check for last run file
try {
    $blobContext = Get-AzStorageBlob `
        -Blob "timestamp.json" `
        -Container $storageAccountContainer `
        -Context $storageAccountContext

} catch {
    Write-Warning "Unable to access [timestamp.json]"
}

if (![string]::IsNullOrEmpty($blobContext)) {
    #Blob found get data
    Write-Output 'Reading last timestamp'
    $null = Get-AzStorageBlobContent `
        -Blob "timestamp.json" `
        -Container $storageAccountContainer `
        -Context $storageAccountContext `
        -Destination "$env:temp\timestamp.json" `
        -Force

    $lastRunAuditContext = Get-Content "$env:temp\timestamp.json" | ConvertFrom-Json
    if ($null -eq $lastRunAuditContext) {
        $lastRunAudit = @{
            'lastRun' = $(Get-Date).AddMinutes(-15).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        }
    }
} else {
    #no blob create the context
    $lastRunAudit = @{
        'lastRun' = $currentStartTime
    }

    $lastRunAudit | ConvertTo-Json | Out-File "$env:temp\timestamp.json"
    $lastRunAuditContext = $lastRunAudit
}

# header for API calls
$headers = @{
    'orgId'         = "$env:OrganizationId"
    'Method'        = 'GET'
    'api-key'       = "$env:apiKey"
    'startDate'     = (Get-Date).AddHours($timeOffset).AddMinutes(-15).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
    'endDate'       = $currentStartTime
    'excludeInfo'   = if ($null -ne $env:excludeInfo) { $env:excludeInfo } else { 'none' }
}

Write-Output $headers.startDate
try {
    $uri = $($env:apiEndpoint)
    $result = (Invoke-RestMethod -Uri $uri -Headers $headers ).data
    Write-Output "Results found: " $($result).count

    if ($result.count -gt 0) {
        $postObject = @{
            "workspaceId"  = $workspaceId
            "WorkspaceKey" = $workspaceKey
            "logType"      = $AuditLogTable
            "body"         = ([System.Text.Encoding]::UTF8.GetBytes(($result | ConvertTo-Json -depth 20)))
        }

        Set-LogAnalyticsData @postObject
    } else {
        Write-Output "no data received"
    }
} catch {
    Write-Warning "Unable to connect to API [$($env:apiEndpoint)]"

    $lastRunAudit = @{
        'lastRun' = $currentStartTime
    }

    $lastRunAudit | ConvertTo-Json | Out-File "$env:temp\timestamp.json"
    Write-Output 'Saving new timestamp'
    $null = Set-AzStorageBlobContent `
        -Blob "timestamp.json" `
        -Container $storageAccountContainer `
        -Context $storageAccountContext `
        -File "$env:temp\timestamp.json" `
        -Force
}

#clear the temp folder
Remove-Item $env:temp\* -Recurse -Force -ErrorAction SilentlyContinue
