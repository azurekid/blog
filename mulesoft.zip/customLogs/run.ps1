<#
    Title:   Mulesoft Logs Collector
    Language:PowerShell
    Version: 1.0
    Author:  Rogier Dijkman
    Last Modified:  03/28/2022

    DESCRIPTION
    This Function App calls an API to pull the Audit logs.
    The response from the Mulesoft API is recieved in JSON format. This function will build the signature and authorization header needed to
    post the data to the Log Analytics workspace via the HTTP Data Connector API.

    The Function App will post each log type to their individual tables in Log Analytics, for example,
    Mulesoft_CL
#>

# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

# Main
if ($env:MSI_SECRET -and (Get-Module -ListAvailable Az.Accounts)) {
    Connect-AzAccount -Identity
}

$AzureWebJobsStorage = $env:AzureWebJobsStorage
# $workspaceId = $env:workspaceId
# $workspaceKey = $env:workspaceKey | ConvertTo-SecureString -AsPlainText -Force
$storageAccountContainer = "custom-logs"
$apiResponseLimit = $env:apiResponseLimit
$AuditLogTable = "AholdMuled"

# Show Variables
Write-Output "AzureWebJobsStorage: $AzureWebJobsStorage"
Write-Output "WorkspaceId: $($env:workspaceId)"
Write-Output "storageAccountContainer: $storageAccountContainer"

$currentStartTime = Get-Date -Format yyyy-MM-ddTHH:mm:ss.fffZ

Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"
$rfc1123date = [DateTime]::UtcNow.ToString("r")

Function Build-Signature {
    param (
        # [Parameter(Mandatory = $true)]
        # [String]$workspaceId,

        # [Parameter(Mandatory = $true)]
        # [SecureString]$workspaceKey,

        [Parameter(Mandatory = $true)]
        [Int32]$contentLength
    )

    $xHeaders = "x-ms-date:" + $rfc1123date
    $stringToHash = "POST" + "`n" + $contentLength + "`n" + "application/json" + "`n" + $xHeaders + "`n" + "/api/logs"
    $bytesToHash = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    #$keyBytes = [Convert]::FromBase64String((ConvertFrom-SecureString -SecureString $($env:workspaceKey) -AsPlainText))
    $keyBytes = [Convert]::FromBase64String($($env:workspaceKey))
    $sha256 = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash = [Convert]::ToBase64String($calculatedHash)
    $authorization = 'SharedKey {0}:{1}' -f $($env:workspaceId), $encodedHash

    return $authorization
}

# Create the function to create and post the request
Function Set-LogAnalyticsData {
    param (
        # [Parameter(Mandatory = $true)]
        # [string]$workspaceId,

        # [Parameter(Mandatory = $true)]
        # [securestring]$workspaceKey,

        [Parameter(Mandatory = $true)]
        [array]$body,

        [Parameter(Mandatory = $true)]
        [string]$logType
    )

    $properties = @{
        # "WorkspaceId"   = $workspaceId
        # "WorkspaceKey"  = $workspaceKey
        "contentLength" = $body.Length
    }

    $payload = @{
        "Headers"     = @{
            "Authorization" = Build-Signature @properties
            "Log-Type"      = $logType
            "x-ms-date"     = $rfc1123date
        }
        "method"      = "POST"
        "contentType" = "application/json"
        "uri"         = "https://{0}.ods.opinsights.azure.com/api/logs?api-version=2016-04-01" -f $($env:workspaceId)
        "body"        = $body
    }

    $response = Invoke-WebRequest @payload -UseBasicParsing

    if (-not($response.StatusCode -eq 200)) {
        Write-Warning "Unable to send data to Data Log Collector table"
        break
    }
    else {
        Write-Output "Uploaded to Data Log Collector table [$($logType + '_CL')] at [$rfc1123date]"
    }
}

$storageAccountContext = New-AzStorageContext -ConnectionString $AzureWebJobsStorage

#check for last run file
try {
    $checkBlob = Get-AzStorageBlob -Blob "timestamp.json" -Container $storageAccountContainer -Context $storageAccountContext
}
catch {
    Write-Warning "Unable to access [timestamp.json]"
}

if (![string]::IsNullOrEmpty($checkBlob)) {
    #Blob found get data
    Write-Output 'reading BLOB content'
    Get-AzStorageBlobContent -Blob "timestamp.json" -Container $storageAccountContainer -Context $storageAccountContext -Destination "$env:temp\timestamp.json" -Force
    $lastRunAuditContext = Get-Content "$env:temp\timestamp.json" | ConvertFrom-Json
    if ($null -eq $lastRunAuditContext) {
        $lastRunAudit = @{
            'lastRun' = $(Get-Date).AddMinutes(-15).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        }
    }
} else {
    #no blob create the context
    Write-Output "Creating new timestamp file"
    $lastRunAudit = @{
        'lastRun' = $currentStartTime
    }

    $lastRunAudit | ConvertTo-Json | Out-File "$env:temp\timestamp.json"
    $lastRunAuditContext = $lastRunAudit

}

# header for API calls
$headers = @{
    'orgId'       = "$env:OrganizationId"
    'Method'      = 'GET'
    'api-key'     = "$env:apiKey"
    'startDate'   = $lastRunAudit.lastRun
    'endDate'     = $currentStartTime
    'excludeInfo' = if ($null -ne $env:excludeInfo) { $env:excludeInfo } else { $null }
}

Write-Output "Headers: " $headers | ConvertTo-Json

# try {
$uri = "$env:apiEndpoint"
$result = (Invoke-RestMethod -Uri $uri -Headers $headers -UseBasicParsing)
Write-Output "Results: $($result.data).count" 

if ($result.count -gt 0) {
    $postObject = @{
        #"workspaceId"  = $($env:workspaceId)
        #"WorkspaceKey" = $($env:WorkspaceKey)
        "logType"      = $AuditLogTable
        "body"         = ([System.Text.Encoding]::UTF8.GetBytes($result.data))
    }

    Write-Output "Posting data to Log Analytics"
    Set-LogAnalyticsData @postObject
    # write lastrun to storage account

    $lastRunAudit.lastRun = $headers.endDate
    $lastRunAudit | ConvertTo-Json | Out-File "$env:temp\timestamp.json"
    Set-AzStorageBlobContent -Blob "timestamp.json" -Container $storageAccountContainer -Context $storageAccountContext -File "$env:temp\timestamp.json" -Force
} else {
    Write-Output "no data received"
}
# }
# catch {
#    Write-Warning "Unable to connect to API [$($env:apiEndpoint)]"
# }

$lastRunAudit.lastRun = $headers.endDate
$lastRunAudit | ConvertTo-Json | Out-File "$env:temp\timestamp.json"
Set-AzStorageBlobContent -Blob "timestamp.json" -Container $storageAccountContainer -Context $storageAccountContext -File "$env:temp\timestamp.json" -Force

#clear the temp folder
Remove-Item $env:temp\* -Recurse -Force -ErrorAction SilentlyContinue
