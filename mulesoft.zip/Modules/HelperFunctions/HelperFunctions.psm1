Function Build-Signature {
    param (
        [Parameter(Mandatory = $true)]
        [String]$workspaceId,

        [Parameter(Mandatory = $true)]
        [SecureString]$workspaceKey,

        [Parameter(Mandatory = $true)]
        [Int32]$contentLength
    )

    $xHeaders       = "x-ms-date:" + $rfc1123date
    $stringToHash   = "POST" + "`n" + $contentLength + "`n" + "application/json" + "`n" + $xHeaders + "`n" + "/api/logs"
    $bytesToHash    = [Text.Encoding]::UTF8.GetBytes($stringToHash)
    $keyBytes       = [Convert]::FromBase64String((ConvertFrom-SecureString -SecureString $workspaceKey -AsPlainText))
    $sha256         = New-Object System.Security.Cryptography.HMACSHA256
    $sha256.Key     = $keyBytes
    $calculatedHash = $sha256.ComputeHash($bytesToHash)
    $encodedHash    = [Convert]::ToBase64String($calculatedHash)
    $authorization  = 'SharedKey {0}:{1}' -f $workspaceId, $encodedHash

    return $authorization
}

# Create the function to create and post the request
Function Set-LogAnalyticsData {
    param (
        [Parameter(Mandatory = $true)]
        [string]$workspaceId,

        [Parameter(Mandatory = $true)]
        [securestring]$workspaceKey,

        [Parameter(Mandatory = $true)]
        [array]$body,

        [Parameter(Mandatory = $true)]
        [string]$logType
    )

    $properties = @{
        "WorkspaceId"   = $workspaceId
        "WorkspaceKey"  = $workspaceKey
        "contentLength" = $body.Length
    }

    $payload = @{
        "Headers"     = @{
            "Authorization" = Build-Signature @properties
            "Log-Type"      = $logType
            "x-ms-date"     = $rfc1123date
        }
        "method"      = "POST"
        "contentType" = "application/json"
        "uri"         = "https://{0}.ods.opinsights.azure.com/api/logs?api-version=2016-04-01" -f $workspaceId
        "body"        = $body
    }

    $response = Invoke-WebRequest @payload -UseBasicParsing

    if (-not($response.StatusCode -eq 200)) {
        Write-Warning "Unable to send data to Data Log Collector table"
        break
    }
    else {
        Write-Output "Uploaded to Data Log Collector table [$($logType + '_CL')] at [$rfc1123date]"
    }
}

Export-ModuleMember -Function "Build-Signature", "Set-LogAnalyticsData"